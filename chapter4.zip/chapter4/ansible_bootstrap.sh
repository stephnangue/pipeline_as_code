#!/bin/bash
set -ex

# Add EPEL repository
sudo amazon-linux-extras install epel -y
sudo yum update -y
sudo yum install -y ansible