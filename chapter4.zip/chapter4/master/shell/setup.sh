#!/bin/bash
printf "\n\n Installing Amazon Linux extras \n\n"
sudo amazon-linux-extras install -y java-openjdk11
sudo amazon-linux-extras install epel -y

sleep 5

printf "\n\n Install Jenkins stable release \n\n"
sudo yum update -y
sudo yum install wget -y
sudo wget -O /etc/yum.repos.d/jenkins.repo http://pkg.jenkins-ci.org/redhat-stable/jenkins.repo
sudo rpm --import https://pkg.jenkins.io/redhat-stable/jenkins.io.key
sudo yum install -y jenkins

printf "\n\n Install git \n\n"
sudo yum install -y git

printf "\n\n Setup SSH key \n\n"
sudo mkdir /var/lib/jenkins/.ssh
sudo touch /var/lib/jenkins/.ssh/known_hosts
sudo chown -R jenkins:jenkins /var/lib/jenkins/.ssh
sudo chmod 700 /var/lib/jenkins/.ssh
sudo mv /tmp/id_rsa /var/lib/jenkins/.ssh/id_rsa
sudo chmod 600 /var/lib/jenkins/.ssh/id_rsa
sudo chown -R jenkins:jenkins /var/lib/jenkins/.ssh/id_rsa

printf "\n\n Configure Jenkins \n\n"
sudo mkdir -p /var/lib/jenkins/init.groovy.d
sudo mv /tmp/scripts/*.groovy /var/lib/jenkins/init.groovy.d/
sudo chown -R jenkins:jenkins /var/lib/jenkins/init.groovy.d
sudo mv /tmp/config/jenkins /etc/sysconfig/jenkins
sudo service jenkins start

printf "\n\n Install Jenkins Plugins \n\n"
sudo chmod +x /tmp/config/install-plugins.sh
sudo bash /tmp/config/install-plugins.sh

