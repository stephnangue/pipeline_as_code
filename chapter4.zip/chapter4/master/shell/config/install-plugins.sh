#!/bin/bash

set -x

#sudo sleep 60

until $(curl --output /dev/null --silent --head --fail http://localhost:8080); do
    printf '.'
    sleep 2
done

sudo wget http://localhost:8080/jnlpJars/jenkins-cli.jar

sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin ace-editor
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin anchore-container-scanner
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin amazon-ecr
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin ant
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin antisamy-markup-formatter
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin apache-httpcomponents-client-4-api
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin async-http-client
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin authentication-tokens
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin aws-credentials
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin block-queued-job
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin blueocean-autofavorite
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin blueocean-bitbucket-pipeline
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin blueocean-commons
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin blueocean-config
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin blueocean-core-js
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin blueocean-dashboard
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin blueocean-display-url
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin blueocean-events
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin blueocean-git-pipeline
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin blueocean-github-pipeline
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin blueocean-i18n
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin blueocean-jira
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin blueocean-jwt
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin blueocean-personalization
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin blueocean-pipeline-api-impl
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin blueocean-pipeline-editor
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin blueocean-pipeline-scm-api
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin blueocean-rest-impl
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin blueocean-rest
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin blueocean-web
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin blueocean
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin bootstrap4-api
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin bouncycastle-api
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin branch-api
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin build-pipeline-plugin
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin checks-api
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin cloudbees-bitbucket-branch-source
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin cloudbees-folder
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin command-launcher
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin conditional-buildstep
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin config-file-provider
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin configuration-as-code
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin credentials-binding
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin credentials
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin dashboard-view
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin display-url-api
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin docker-commons
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin docker-workflow
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin durable-task
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin ec2
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin echarts-api
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin email-ext
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin embeddable-build-status
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin external-monitor-job
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin favorite
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin font-awesome-api
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin git-client
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin git-server
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin git
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin github-api
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin github-branch-source
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin github-pullrequest
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin github
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin handlebars
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin handy-uri-templates-2-api
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin htmlpublisher
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin jackson2-api
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin javadoc
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin jdk-tool
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin jenkins-design-language
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin jira
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin jjwt-api
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin job-dsl
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin jquery-detached
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin jquery
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin jquery3-api
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin jsch
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin jucies
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin junit
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin ldap
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin lockable-resources
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin mailer
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin managed-scripts
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin mapdb-api
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin matrix-auth
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin matrix-project
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin maven-plugin
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin mercurial
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin metrics
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin momentjs
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin node-iterator-api
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin okhttp-api
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin p4
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin pam-auth
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin parameterized-trigger
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin pipeline-build-step
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin pipeline-graph-analysis
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin pipeline-input-step
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin pipeline-milestone-step
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin pipeline-model-api
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin pipeline-model-definition
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin pipeline-model-extensions
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin pipeline-multibranch-defaults
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin pipeline-rest-api
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin pipeline-stage-step
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin pipeline-stage-tags-metadata
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin pipeline-stage-view
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin plain-credentials
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin plugin-util-api
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin popper-api
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin project-inheritance
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin promoted-builds
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin pubsub-light
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin rebuild
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin run-condition
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin scm-api
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin script-security
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin slack
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin sonar  
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin snakeyaml-api
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin sse-gateway
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin ssh-agent
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin ssh-credentials
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin ssh-slaves
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin ssh
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin structs
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin subversion
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin support-core
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin token-macro
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin trilead-api
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin variant
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin windows-slaves
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin workflow-aggregator
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin workflow-api
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin workflow-basic-steps
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin workflow-cps-global-lib
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin workflow-cps
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin workflow-durable-task-step
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin workflow-job
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin workflow-multibranch
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin workflow-scm-step
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin workflow-step-api
sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane install-plugin workflow-support  

sudo java -jar jenkins-cli.jar -s http://localhost:8080/ -auth stephane:stephane safe-restart
sudo rm -f jenkins-cli.jar