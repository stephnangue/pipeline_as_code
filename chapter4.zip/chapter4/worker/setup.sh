#!/bin/bash
printf "\n\n Installing Amazon Linux extras \n\n"
sudo amazon-linux-extras install -y java-openjdk11
sudo amazon-linux-extras install epel -y

sleep 5

printf "\n\n Install Docker engine \n\n"
sudo yum update -y
sudo yum install docker -y
sudo usermod -aG docker ec2-user
sudo systemctl enable docker

printf "\n\n Install git \n\n"
sudo yum install -y git

echo "Install SonarScanner"
wget https://binaries.sonarsource.com/Distribution/sonar-scanner-cli/sonar-scanner-cli-4.2.0.1873-linux.zip -P /tmp
unzip /tmp/sonar-scanner-cli-4.2.0.1873-linux.zip
mv sonar-scanner-4.2.0.1873-linux sonar-scanner
ln -sf /home/ec2-user/sonar-scanner/bin/sonar-scanner /usr/bin/sonar-scanner